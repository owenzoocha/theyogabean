-- MySQL dump 10.13  Distrib 5.5.44, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: yogabean
-- ------------------------------------------------------
-- Server version	5.5.44-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accesstokens`
--

DROP TABLE IF EXISTS `accesstokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accesstokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `expires` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accesstokens_token_unique` (`token`),
  KEY `accesstokens_user_id_foreign` (`user_id`),
  KEY `accesstokens_client_id_foreign` (`client_id`),
  CONSTRAINT `accesstokens_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `accesstokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accesstokens`
--

LOCK TABLES `accesstokens` WRITE;
/*!40000 ALTER TABLE `accesstokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `accesstokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_fields`
--

DROP TABLE IF EXISTS `app_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `type` varchar(150) NOT NULL DEFAULT 'html',
  `app_id` int(10) unsigned NOT NULL,
  `relatable_id` int(10) unsigned NOT NULL,
  `relatable_type` varchar(150) NOT NULL DEFAULT 'posts',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `app_fields_app_id_foreign` (`app_id`),
  CONSTRAINT `app_fields_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_fields`
--

LOCK TABLES `app_fields` WRITE;
/*!40000 ALTER TABLE `app_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `app_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`),
  KEY `app_settings_app_id_foreign` (`app_id`),
  CONSTRAINT `app_settings_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `version` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'inactive',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `apps_name_unique` (`name`),
  UNIQUE KEY `apps_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps`
--

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_trusted_domains`
--

DROP TABLE IF EXISTS `client_trusted_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_trusted_domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `trusted_domain` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_trusted_domains_client_id_foreign` (`client_id`),
  CONSTRAINT `client_trusted_domains_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_trusted_domains`
--

LOCK TABLES `client_trusted_domains` WRITE;
/*!40000 ALTER TABLE `client_trusted_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_trusted_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `secret` varchar(150) NOT NULL,
  `redirection_uri` varchar(2000) DEFAULT NULL,
  `logo` varchar(2000) DEFAULT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'development',
  `type` varchar(150) NOT NULL DEFAULT 'ua',
  `description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_name_unique` (`name`),
  UNIQUE KEY `clients_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'6472525a-a0e2-42b8-a7b4-8e92bbafca67','Ghost Admin','ghost-admin','0efc44eee503',NULL,NULL,'enabled','ua',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(2,'6d0dd0a1-bc90-4791-a3ec-010ec02a7476','Ghost Frontend','ghost-frontend','8f26b223582f',NULL,NULL,'enabled','ua',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `object_type` varchar(150) NOT NULL,
  `action_type` varchar(150) NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'2c062dae-5e28-4368-a3d6-b82a6f07c066','Export database','db','exportContent',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(2,'1eedd700-b46d-4ea4-87d8-8ea31b87b5f6','Import database','db','importContent',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(3,'f9afe556-72ed-441b-929e-c1e2c41d2719','Delete all content','db','deleteAllContent',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(4,'15f368f7-9c9c-4b2a-a73c-4431fc1ed715','Send mail','mail','send',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(5,'05044b78-d633-4baa-9991-9b37f312db8b','Browse notifications','notification','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(6,'a947babb-01ff-4717-8998-5f318afb11cd','Add notifications','notification','add',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(7,'5de112e2-0a0d-40d8-accb-b00b5bb34480','Delete notifications','notification','destroy',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(8,'418f1e7c-bbd2-4778-9c53-d8f3dc4189ae','Browse posts','post','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(9,'4c4e60af-5282-4aed-81c8-bb82ed613028','Read posts','post','read',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(10,'b97ece9c-049d-4952-850a-28eeba281453','Edit posts','post','edit',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(11,'f1997aeb-ecae-4a7e-a215-b17739c6546c','Add posts','post','add',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(12,'95a93539-d4a9-4fb9-a97f-e19ea9e96f2a','Delete posts','post','destroy',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(13,'302e3b33-4a2d-4f1f-9c95-355cbdbe3e48','Browse settings','setting','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(14,'b5d78547-ef18-422f-b523-83869c6f58ce','Read settings','setting','read',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(15,'6fc72cf1-975f-4bfd-bb0d-0b9c052f872f','Edit settings','setting','edit',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(16,'832088c8-7528-494e-8802-6f15e90cff80','Generate slugs','slug','generate',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(17,'3325276d-6881-4ca5-a428-9c1829106748','Browse tags','tag','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(18,'d82be8de-d068-4210-8b16-a797bd1936ab','Read tags','tag','read',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(19,'0e8f27e3-91c7-4846-861f-f765159c86fd','Edit tags','tag','edit',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(20,'5bca98f5-5f47-4bbd-8e3b-8c1bf5d7ff7e','Add tags','tag','add',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(21,'39c54e9f-33ee-4713-92ae-faf0715f1d02','Delete tags','tag','destroy',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(22,'a43bd4eb-4ff4-476e-804e-68aef6fdcfc7','Browse themes','theme','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(23,'3ebe616b-b0b6-47b8-9bfd-edafa11b7388','Edit themes','theme','edit',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(24,'e4abce4f-1a10-49b6-acd3-89aa7b24c667','Browse users','user','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(25,'9cb9aaae-aa99-4e50-ae4f-b33a9882e446','Read users','user','read',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(26,'40a1ead6-0551-474f-83a6-a26a0959df8a','Edit users','user','edit',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(27,'57727b86-ce63-49ac-98b4-ef4f0ab269be','Add users','user','add',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(28,'cbafdb81-b22e-41cf-b821-16530fc9cf71','Delete users','user','destroy',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(29,'6a5ea077-e50a-48bd-95d9-0aa6f6a77bf9','Assign a role','role','assign',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(30,'5b7e88cb-ded9-4462-ba9f-fcdab02920aa','Browse roles','role','browse',NULL,'2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_apps`
--

DROP TABLE IF EXISTS `permissions_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_apps`
--

LOCK TABLES `permissions_apps` WRITE;
/*!40000 ALTER TABLE `permissions_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_roles`
--

DROP TABLE IF EXISTS `permissions_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_roles`
--

LOCK TABLES `permissions_roles` WRITE;
/*!40000 ALTER TABLE `permissions_roles` DISABLE KEYS */;
INSERT INTO `permissions_roles` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,1,15),(16,1,16),(17,1,17),(18,1,18),(19,1,19),(20,1,20),(21,1,21),(22,1,22),(23,1,23),(24,1,24),(25,1,25),(26,1,26),(27,1,27),(28,1,28),(29,1,29),(30,1,30),(31,3,8),(32,3,9),(33,3,11),(34,3,13),(35,3,14),(36,3,16),(37,3,17),(38,3,18),(39,3,20),(40,3,24),(41,3,25),(42,3,30),(43,2,8),(44,2,9),(45,2,10),(46,2,11),(47,2,12),(48,2,13),(49,2,14),(50,2,16),(51,2,17),(52,2,18),(53,2,19),(54,2,20),(55,2,21),(56,2,24),(57,2,25),(58,2,26),(59,2,27),(60,2,28),(61,2,29),(62,2,30);
/*!40000 ALTER TABLE `permissions_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_users`
--

DROP TABLE IF EXISTS `permissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_users`
--

LOCK TABLES `permissions_users` WRITE;
/*!40000 ALTER TABLE `permissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `title` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `markdown` mediumtext,
  `html` mediumtext,
  `image` text,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `page` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(150) NOT NULL DEFAULT 'draft',
  `language` varchar(6) NOT NULL DEFAULT 'en_US',
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `published_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'736fa47a-9133-423d-bdd1-ad7050c72ecb','Welcome to Ghost','welcome-to-ghost','You\'re live! Nice. We\'ve put together a little post to introduce you to the Ghost editor and get you started. You can manage your content by signing in to the admin area at `<your blog URL>/ghost/`. When you arrive, you can select this post from a list on the left and see a preview of it on the right. Click the little pencil icon at the top of the preview to edit this post and read the next section!\n\n## Getting Started\n\nGhost uses something called Markdown for writing. Essentially, it\'s a shorthand way to manage your post formatting as you write!\n\nWriting in Markdown is really easy. In the left hand panel of Ghost, you simply write as you normally would. Where appropriate, you can use *shortcuts* to **style** your content. For example, a list:\n\n* Item number one\n* Item number two\n    * A nested item\n* A final item\n\nor with numbers!\n\n1. Remember to buy some milk\n2. Drink the milk\n3. Tweet that I remembered to buy the milk, and drank it\n\n### Links\n\nWant to link to a source? No problem. If you paste in a URL, like http://ghost.org - it\'ll automatically be linked up. But if you want to customise your anchor text, you can do that too! Here\'s a link to [the Ghost website](http://ghost.org). Neat.\n\n### What about Images?\n\nImages work too! Already know the URL of the image you want to include in your article? Simply paste it in like this to make it show up:\n\n![The Ghost Logo](https://ghost.org/images/ghost.png)\n\nNot sure which image you want to use yet? That\'s ok too. Leave yourself a descriptive placeholder and keep writing. Come back later and drag and drop the image in to upload:\n\n![A bowl of bananas]\n\n\n### Quoting\n\nSometimes a link isn\'t enough, you want to quote someone on what they\'ve said. Perhaps you\'ve started using a new blogging platform and feel the sudden urge to share their slogan? A quote might be just the way to do it!\n\n> Ghost - Just a blogging platform\n\n### Working with Code\n\nGot a streak of geek? We\'ve got you covered there, too. You can write inline `<code>` blocks really easily with back ticks. Want to show off something more comprehensive? 4 spaces of indentation gets you there.\n\n    .awesome-thing {\n        display: block;\n        width: 100%;\n    }\n\n### Ready for a Break? \n\nThrow 3 or more dashes down on any new line and you\'ve got yourself a fancy new divider. Aw yeah.\n\n---\n\n### Advanced Usage\n\nThere\'s one fantastic secret about Markdown. If you want, you can write plain old HTML and it\'ll still work! Very flexible.\n\n<input type=\"text\" placeholder=\"I\'m an input field!\" />\n\nThat should be enough to get you started. Have fun - and let us know what you think :)','<p>You\'re live! Nice. We\'ve put together a little post to introduce you to the Ghost editor and get you started. You can manage your content by signing in to the admin area at <code>&lt;your blog URL&gt;/ghost/</code>. When you arrive, you can select this post from a list on the left and see a preview of it on the right. Click the little pencil icon at the top of the preview to edit this post and read the next section!</p>\n\n<h2 id=\"gettingstarted\">Getting Started</h2>\n\n<p>Ghost uses something called Markdown for writing. Essentially, it\'s a shorthand way to manage your post formatting as you write!</p>\n\n<p>Writing in Markdown is really easy. In the left hand panel of Ghost, you simply write as you normally would. Where appropriate, you can use <em>shortcuts</em> to <strong>style</strong> your content. For example, a list:</p>\n\n<ul>\n<li>Item number one</li>\n<li>Item number two\n<ul><li>A nested item</li></ul></li>\n<li>A final item</li>\n</ul>\n\n<p>or with numbers!</p>\n\n<ol>\n<li>Remember to buy some milk  </li>\n<li>Drink the milk  </li>\n<li>Tweet that I remembered to buy the milk, and drank it</li>\n</ol>\n\n<h3 id=\"links\">Links</h3>\n\n<p>Want to link to a source? No problem. If you paste in a URL, like <a href=\"http://ghost.org\">http://ghost.org</a> - it\'ll automatically be linked up. But if you want to customise your anchor text, you can do that too! Here\'s a link to <a href=\"http://ghost.org\">the Ghost website</a>. Neat.</p>\n\n<h3 id=\"whataboutimages\">What about Images?</h3>\n\n<p>Images work too! Already know the URL of the image you want to include in your article? Simply paste it in like this to make it show up:</p>\n\n<p><img src=\"https://ghost.org/images/ghost.png\" alt=\"The Ghost Logo\" /></p>\n\n<p>Not sure which image you want to use yet? That\'s ok too. Leave yourself a descriptive placeholder and keep writing. Come back later and drag and drop the image in to upload:</p>\n\n<h3 id=\"quoting\">Quoting</h3>\n\n<p>Sometimes a link isn\'t enough, you want to quote someone on what they\'ve said. Perhaps you\'ve started using a new blogging platform and feel the sudden urge to share their slogan? A quote might be just the way to do it!</p>\n\n<blockquote>\n  <p>Ghost - Just a blogging platform</p>\n</blockquote>\n\n<h3 id=\"workingwithcode\">Working with Code</h3>\n\n<p>Got a streak of geek? We\'ve got you covered there, too. You can write inline <code>&lt;code&gt;</code> blocks really easily with back ticks. Want to show off something more comprehensive? 4 spaces of indentation gets you there.</p>\n\n<pre><code>.awesome-thing {\n    display: block;\n    width: 100%;\n}\n</code></pre>\n\n<h3 id=\"readyforabreak\">Ready for a Break?</h3>\n\n<p>Throw 3 or more dashes down on any new line and you\'ve got yourself a fancy new divider. Aw yeah.</p>\n\n<hr />\n\n<h3 id=\"advancedusage\">Advanced Usage</h3>\n\n<p>There\'s one fantastic secret about Markdown. If you want, you can write plain old HTML and it\'ll still work! Very flexible.</p>\n\n<p><input type=\"text\" placeholder=\"I\'m an input field!\" /></p>\n\n<p>That should be enough to get you started. Have fun - and let us know what you think :)</p>',NULL,0,0,'draft','en_US',NULL,NULL,1,'2016-01-30 21:56:44',1,'2016-02-01 21:55:35',1,'2016-01-30 21:56:44',1),(2,'509258a2-5398-45ba-9fb4-88dee4800c36','About','about','# Welcome to The Yoga Bean. \nIâ€™m Lizzie, I\'m from **Wales**, but living in \n**Melbourne, Australia** - Iâ€™m 25 years old and I want to share my yoga story with you. \n\nI started my yoga journey when I was 19, as it fitted in well with my ambition to become a professional dancer. This blog is about how my yoga journey has helped shape my life. How my dreams and ambitions have changed, but yoga has been one of the only things that has helped support, encourage and ensure me that it was okay for that to happen. \n\nYoga is something that is truly magical, I am writing this blog to help encourage, inspire and maybe in some way or another shape the beautiful journey that is your yoga story.  I hope you enjoy my little space. \n\n**LM** x\n','<h1 id=\"welcometotheyogabean\">Welcome to The Yoga Bean.</h1>\n\n<p>Iâ€™m Lizzie, I\'m from <strong>Wales</strong>, but living in <br />\n<strong>Melbourne, Australia</strong> - Iâ€™m 25 years old and I want to share my yoga story with you. </p>\n\n<p>I started my yoga journey when I was 19, as it fitted in well with my ambition to become a professional dancer. This blog is about how my yoga journey has helped shape my life. How my dreams and ambitions have changed, but yoga has been one of the only things that has helped support, encourage and ensure me that it was okay for that to happen. </p>\n\n<p>Yoga is something that is truly magical, I am writing this blog to help encourage, inspire and maybe in some way or another shape the beautiful journey that is your yoga story.  I hope you enjoy my little space. </p>\n\n<p><strong>LM</strong> x</p>','',1,1,'published','en_US','About The Yoga Bean','The Yoga Bean is the blog space of Lizzie Manjon - an aspiring yogi currently based in Melbourne, Australia.  An encourager of all things wonderful.',1,'2016-01-31 09:13:05',1,'2016-02-01 22:23:50',1,'2016-01-31 09:24:27',1),(3,'de677998-085a-4844-ba0b-14353998eaaf','Introduction','introduction','Welcome to **The Yoga Bean** blog. \n\nI am writing this to help encourage, inspire and maybe in some way or another - shape the beautiful journey that is your yoga story. I hope you enjoy my little space.\n\nIf you\'d like to keep up to date with my journey, please subscribe, share, like and comment.  I look forward to hearing from you :)\n\n**LM** x','<p>Welcome to <strong>The Yoga Bean</strong> blog. </p>\n\n<p>I am writing this to help encourage, inspire and maybe in some way or another - shape the beautiful journey that is your yoga story. I hope you enjoy my little space.</p>\n\n<p>If you\'d like to keep up to date with my journey, please subscribe, share, like and comment.  I look forward to hearing from you :)</p>\n\n<p><strong>LM</strong> x</p>','/content/images/2016/01/10906132_834713009174_910519941963116121_n.jpg',0,0,'published','en_US',NULL,NULL,1,'2016-01-31 14:35:49',1,'2016-02-02 21:11:51',1,'2016-01-31 14:36:11',1),(4,'d0bffc64-e519-4fa0-a05b-95250adbddf8','Advertise','advertise','If you\'re interested in advertising on The Yoga Bean - feel free to get in touch with [Lizzie](mailto:theyogabeanuk@gmail.com) @ TYB :)\n\n','<p>If you\'re interested in advertising on The Yoga Bean - feel free to get in touch with <a href=\"mailto:theyogabeanuk@gmail.com\">Lizzie</a> @ TYB :)</p>',NULL,0,1,'published','en_US','Advertise',NULL,1,'2016-02-01 21:39:53',1,'2016-02-01 21:42:23',1,'2016-02-01 21:41:37',1),(5,'6436518c-2d7d-41e7-a386-5e5f2c83f5c9','Why Yoga?','why-yoga','My yoga journey started when I was 19 in 2009 and it started totally by accident. As a dancer on a full time dance course we had 3 hours of yoga a week, to compliment our other classes and to improve our flexibility and strength. I have to say that I was not taken by it straight away. As a naÃ¯ve 19 year old whose end goal was being able to do the splits both ways without having to warm up yoga was the last thing I wanted to do. Why was I making these strange shapes with my body? Being told to be still in them? For once not being praised for my hyper flexibility and the beautiful shape I could create but being told to be patient with my body, and to really feel the experience for as long as possible? My 19 year old dancer egotistical impatient brain did not understand. I wanted to be the best, and I wanted to be the best right there and then, I wanted results and I didnâ€™t want to wait for them. What I knew deep down in my heart was that I most certainly did not want was any more yoga *yawn* (especially if I was going to be told off for locking my knees! I loved my sway back)\nFast forward six years and I could not be any further away from that young, slightly narcissistic impatient prima diva ballerina. Why is that you ask me? Yoga is why.\n\nI was going through a really rough time when I was in dance college as I was in the process of being diagnosed with some sort of mental illness and it was very likely that it was bi-polar (Iâ€™m still not completely diagnosed). So you add that to being in a class full of some lovely, talented however sometimes very temperamental dancers, who I always seemed to find myself competing with in one way or another then you can realize how much of a hectic place my head must have been to live. One of the things I actually remember most about this very unsettled year was at the end of one yoga class, doing savasana and feeling like this was the first time I had felt peaceful in about a year, a feeling of calm just washed over my body and for a brief 3 minutes I felt like everything had been taken away. Though I didnâ€™t know it this was the beginning of my yoga journey.\n \nThe next few years were more hectic than 2009. I was living in London, working in a Gym and going to Musical Theatre College, I dropped out, moved to Spain and toured 4 shows around schools and then finally I moved to Australia which is where I still am. I was always looking for ways to keep fit, to keep my flexibility up and also to try and engage my somewhat troubled mind. For some reason no matter where I was living, I always ended up winding my way back to yoga.\n \nI went back into the studio first at the gym that I was working at, expecting a class full of poses I didnâ€™t understand and hippies with flowers in their hair but I could not have been further from wrong. I have always practiced Vinyasa yoga flow, which was what this class was however for some reason I felt engaged. The flow was almost like a dance routine, moving between one posture to the next and for the first time in my life I felt like the routine I was doing wasnâ€™t for anybody else; it was for me. That was the first time I could truly feel my body. I wasnâ€™t perfect but I didnâ€™t need to be, I was inside myself and connected to the present moment (for most of the time anyway.) Though I moved countries, changed jobs and lifestyles over the next few years there was one thing that was (nearly) consistent - my yoga practice.\n \nIts like yoga has followed me around, or maybe I have always been drawn to yoga subconsciously but it was never completely the right time until recently. Although I have always dipped in and out since being here in Melbourne I have been practising yoga every day for the past 8 months and I have never felt more alive, connected or more stable, mentally and physically.\n \nFor me yoga is a breath of fresh air, it lightens my spirit and it gives me hope. Hope is such a strong word. When I was 19 I spent every day hoping I would get into the right dance school, the right company, the right show. I now have a very different understanding of the word hope. I feel like what I used to believe was hope is now intent and my intentions are very different to what I used to â€˜hopeâ€™ for. Every yoga practise I focus my intent towards something different, towards my path of growing and trusting more. Or towards special people in my life who might need some positive thoughts being sent their way. Hope is something you wish will happen, where as in intent is something you are carving out yourselfâ€¦\n \nI wanted to explain to you why on my life journey I choose yoga. I would love my blogs to  help inspire you on your yogi journey, if you haven\'t asked yourself why yoga? before then maybe now is time. Keep being wonderful â€“ I cant encourage it enough.\n \nNamaste Yogis.\n \n**LM** x\n ','<p>My yoga journey started when I was 19 in 2009 and it started totally by accident. As a dancer on a full time dance course we had 3 hours of yoga a week, to compliment our other classes and to improve our flexibility and strength. I have to say that I was not taken by it straight away. As a naÃ¯ve 19 year old whose end goal was being able to do the splits both ways without having to warm up yoga was the last thing I wanted to do. Why was I making these strange shapes with my body? Being told to be still in them? For once not being praised for my hyper flexibility and the beautiful shape I could create but being told to be patient with my body, and to really feel the experience for as long as possible? My 19 year old dancer egotistical impatient brain did not understand. I wanted to be the best, and I wanted to be the best right there and then, I wanted results and I didnâ€™t want to wait for them. What I knew deep down in my heart was that I most certainly did not want was any more yoga <em>yawn</em> (especially if I was going to be told off for locking my knees! I loved my sway back) <br />\nFast forward six years and I could not be any further away from that young, slightly narcissistic impatient prima diva ballerina. Why is that you ask me? Yoga is why.</p>\n\n<p>I was going through a really rough time when I was in dance college as I was in the process of being diagnosed with some sort of mental illness and it was very likely that it was bi-polar (Iâ€™m still not completely diagnosed). So you add that to being in a class full of some lovely, talented however sometimes very temperamental dancers, who I always seemed to find myself competing with in one way or another then you can realize how much of a hectic place my head must have been to live. One of the things I actually remember most about this very unsettled year was at the end of one yoga class, doing savasana and feeling like this was the first time I had felt peaceful in about a year, a feeling of calm just washed over my body and for a brief 3 minutes I felt like everything had been taken away. Though I didnâ€™t know it this was the beginning of my yoga journey.</p>\n\n<p>The next few years were more hectic than 2009. I was living in London, working in a Gym and going to Musical Theatre College, I dropped out, moved to Spain and toured 4 shows around schools and then finally I moved to Australia which is where I still am. I was always looking for ways to keep fit, to keep my flexibility up and also to try and engage my somewhat troubled mind. For some reason no matter where I was living, I always ended up winding my way back to yoga.</p>\n\n<p>I went back into the studio first at the gym that I was working at, expecting a class full of poses I didnâ€™t understand and hippies with flowers in their hair but I could not have been further from wrong. I have always practiced Vinyasa yoga flow, which was what this class was however for some reason I felt engaged. The flow was almost like a dance routine, moving between one posture to the next and for the first time in my life I felt like the routine I was doing wasnâ€™t for anybody else; it was for me. That was the first time I could truly feel my body. I wasnâ€™t perfect but I didnâ€™t need to be, I was inside myself and connected to the present moment (for most of the time anyway.) Though I moved countries, changed jobs and lifestyles over the next few years there was one thing that was (nearly) consistent - my yoga practice.</p>\n\n<p>Its like yoga has followed me around, or maybe I have always been drawn to yoga subconsciously but it was never completely the right time until recently. Although I have always dipped in and out since being here in Melbourne I have been practising yoga every day for the past 8 months and I have never felt more alive, connected or more stable, mentally and physically.</p>\n\n<p>For me yoga is a breath of fresh air, it lightens my spirit and it gives me hope. Hope is such a strong word. When I was 19 I spent every day hoping I would get into the right dance school, the right company, the right show. I now have a very different understanding of the word hope. I feel like what I used to believe was hope is now intent and my intentions are very different to what I used to â€˜hopeâ€™ for. Every yoga practise I focus my intent towards something different, towards my path of growing and trusting more. Or towards special people in my life who might need some positive thoughts being sent their way. Hope is something you wish will happen, where as in intent is something you are carving out yourselfâ€¦</p>\n\n<p>I wanted to explain to you why on my life journey I choose yoga. I would love my blogs to  help inspire you on your yogi journey, if you haven\'t asked yourself why yoga? before then maybe now is time. Keep being wonderful â€“ I cant encourage it enough.</p>\n\n<p>Namaste Yogis.</p>\n\n<p><strong>LM</strong> x</p>',NULL,0,0,'published','en_US',NULL,NULL,1,'2016-02-02 21:06:09',1,'2016-02-02 21:08:32',1,'2016-02-02 21:08:32',1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `posts_tags_post_id_foreign` (`post_id`),
  KEY `posts_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `posts_tags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_tags`
--

LOCK TABLES `posts_tags` WRITE;
/*!40000 ALTER TABLE `posts_tags` DISABLE KEYS */;
INSERT INTO `posts_tags` VALUES (2,2,2,0),(3,4,9,0),(4,3,9,0),(5,5,9,0),(6,5,3,1),(7,5,2,2);
/*!40000 ALTER TABLE `posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refreshtokens`
--

DROP TABLE IF EXISTS `refreshtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refreshtokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `expires` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refreshtokens_token_unique` (`token`),
  KEY `refreshtokens_user_id_foreign` (`user_id`),
  KEY `refreshtokens_client_id_foreign` (`client_id`),
  CONSTRAINT `refreshtokens_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `refreshtokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refreshtokens`
--

LOCK TABLES `refreshtokens` WRITE;
/*!40000 ALTER TABLE `refreshtokens` DISABLE KEYS */;
INSERT INTO `refreshtokens` VALUES (1,'4Q0j9Hysd5xntY3d8JHFYpsVrGiNqISvq8cQbH9VNLA9uSw2fBlEj1bkbaFukKJhW41Q6HKm5S3pu6UHxWyevkr2tgmr7Z2RjoY5iIyQQJiyIjiVE7r1Vz0o1Ow1TiFQVLClY9weOAkwa13G3f9bjdktANVwxiESft1t1p2qlo7ruXpwfOjRrzEyGaLN5tddmmg16o7HhLCoefWTmaTsvKQ6OYWQWLat0z9VqH6nRlBubwm2pM7cGbnbJaiHQr2',1,1,1454796740092),(2,'aJK5baXkCKIiZwbxlDXzgWWmHDFNWudRAiQnzWK3QKFJjK02hPixjNyrCdeA7qIdyw3OdWkJUDdZSrveEYJFdVf4Hy6Y9yhHLcKLMlvXz4dXeBNrjJUAxruyG5nh13UKVzGEuIC3jVxblkM60HrEzqKw1Hb2CuvpLHNBTbBR6LwvhNeh6Z8Bv1S4gR7zuwp1LhaXbgjVcrII2vNZdmIhHtpgfXXP6nyego15U5nLI5YnCvUCckQ8F0ASobcOfpe',1,1,1455017373969);
/*!40000 ALTER TABLE `refreshtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'82738ac5-0e47-404b-9bce-e56b0efda475','Administrator','Administrators','2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(2,'cd16c73a-86cc-4a3d-924f-20e281104809','Editor','Editors','2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(3,'f081d19d-d9f8-4fec-a74e-97168580e3ed','Author','Authors','2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1),(4,'c77290cf-1e0c-41fa-a7fd-079f09940746','Owner','Blog Owner','2016-01-30 21:56:44',1,'2016-01-30 21:56:44',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` VALUES (1,4,1),(2,1,2);
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `type` varchar(150) NOT NULL DEFAULT 'core',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'0dd865f7-36b7-4cfd-b752-eefd34bcd954','databaseVersion','004','core','2016-01-30 21:56:45',1,'2016-01-30 21:56:45',1),(2,'e2bbbd97-dc19-45f2-9e61-696dfe272f3e','dbHash','14b7c177-73a8-42c6-8b12-1fe309ea0b49','core','2016-01-30 21:56:45',1,'2016-01-30 21:56:46',1),(3,'2bc6404c-4df2-4f1c-8fb5-a98dd5bb3285','nextUpdateCheck','1454493943','core','2016-01-30 21:56:45',1,'2016-02-02 21:05:43',1),(4,'80c04e27-4016-4388-970c-f712bc40c347','displayUpdateNotification','0.5.0','core','2016-01-30 21:56:45',1,'2016-02-02 21:05:43',1),(5,'8edcba58-f702-4be4-abf7-cf448fec3c7b','title','Encourager of all things wonderful | The Yoga Bean','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(6,'e9d55288-02d2-4dc0-a357-6790c3115aa4','description','My little place, my little space. Hi I\'m Lizzie, this blog is to share my magical journey of yoga, to encourage and inspire fellow yogis - new or experienced. Let your light shine and spirit soar\n','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(7,'7bf2adc0-786e-4f22-8c0f-aa0de254e198','logo','/content/images/2016/01/tyb.png','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(8,'eae5e7e9-c2b8-422e-b5fc-fe5581f0c2f7','cover','','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(9,'663bcce2-3298-49af-b876-53cab8eec2e9','defaultLang','en_US','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(10,'42905238-8789-4feb-a545-9bf8274a04ed','postsPerPage','5','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(11,'484115e1-7654-4fb6-aef1-c2bfa971fc64','forceI18n','true','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(12,'330a5c7c-ee3a-4973-9399-53dba3b2c56d','permalinks','/:slug/','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(13,'7c8b0da9-bbfe-4f5f-a239-2ff7afb062a1','ghost_head','','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(14,'40acd6bf-b641-4504-90b4-e0e496561caf','ghost_foot','','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(15,'51819ae3-f666-43e7-b2c7-a05b8be409ad','labs','{}','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(16,'b3b9d0ba-2293-4c2f-b3e1-7376368d4ce1','navigation','[{\"label\":\"Home\",\"url\":\"/\"},{\"label\":\"About\",\"url\":\"/about/\"},{\"label\":\"Yoga\",\"url\":\"/tag/yoga/\"}]','blog','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(17,'a4f62be9-d256-4201-8347-437a8f7fe596','activeApps','[]','app','2016-01-30 21:56:45',1,'2016-01-30 21:56:45',1),(18,'f48da3f8-0981-478d-9084-9a66bfc32072','installedApps','[]','app','2016-01-30 21:56:45',1,'2016-02-04 21:37:29',1),(19,'386881a1-642d-4398-b474-53f8891bd02d','isPrivate','false','private','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(20,'ec786145-54a8-48fd-aa4e-208d949e855b','password','null','private','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1),(21,'424224af-d440-4b2f-8944-60e0c310dc62','activeTheme','lark','theme','2016-01-30 21:56:45',1,'2016-02-02 21:16:19',1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `image` text,
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (2,'14291d08-909b-44f0-8b11-7f8baa1560cb','yoga','yoga',NULL,NULL,0,NULL,NULL,NULL,'2016-01-31 09:26:22',1,'2016-01-31 09:26:22',1),(3,'1c8a88e9-eb33-4bba-b125-1e74622e87b6','mindfulness','mindfulness',NULL,NULL,0,NULL,'Mindfulness','','2016-02-01 21:27:10',1,'2016-02-01 21:27:29',1),(4,'6103b440-0d71-4109-8b1c-0373fdac7379','yogi','yogi',NULL,NULL,0,NULL,'Yogi','','2016-02-01 21:28:16',1,'2016-02-01 21:28:31',1),(5,'13dc3417-7a79-4670-af2f-efc1cdced04d','health','health',NULL,NULL,0,NULL,'Health',NULL,'2016-02-01 21:28:49',1,'2016-02-01 21:29:05',1),(6,'01e959ec-1156-4d92-8fbc-e9b3f45cbc2b','fitness','fitness',NULL,NULL,0,NULL,'Fitness',NULL,'2016-02-01 21:29:12',1,'2016-02-01 21:29:19',1),(7,'1982577d-b0e0-4895-93f1-d77cf05f7ea2','hot yoga','hot-yoga','',NULL,0,NULL,'Hot Yoga',NULL,'2016-02-01 21:35:01',1,'2016-02-01 21:35:08',1),(8,'67f5933e-5dcd-4019-9fcd-a0f79b975b9e','yoga poses','yoga-poses','',NULL,0,NULL,'Yoga Poses',NULL,'2016-02-01 21:35:26',1,'2016-02-01 21:35:32',1),(9,'380a7897-6362-454c-b974-77650629a2cb','the yoga bean','the-yoga-bean','',NULL,0,NULL,'The Yoga Bean',NULL,'2016-02-01 21:37:24',1,'2016-02-01 22:30:54',1),(10,'257ce7c2-84d4-4149-8614-2fbc63601e80','videos','video','Check out The Yoga Bean\'s videos, tutorials and tips',NULL,0,NULL,'Videos',NULL,'2016-02-01 22:11:30',1,'2016-02-01 22:12:39',1);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(254) NOT NULL,
  `image` text,
  `cover` text,
  `bio` varchar(200) DEFAULT NULL,
  `website` text,
  `location` text,
  `accessibility` text,
  `status` varchar(150) NOT NULL DEFAULT 'active',
  `language` varchar(6) NOT NULL DEFAULT 'en_US',
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `tour` text,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_slug_unique` (`slug`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'6441d846-aa63-4bfc-9d65-eaf683d1af36','Lizzie Manjon','lizzie','$2a$10$hgzuqF3WZXgLjy0/T155OuSA0TOqoJHXNKTCbM19nUk4Yxclnyeb2','theyogabeanuk@gmail.com','/content/images/2016/01/11225364_10155782786085253_2741127072493726909_n.jpg',NULL,'Love yoga!','http://theyogabean.co.uk','Melbourne, Australia',NULL,'active','en_US',NULL,NULL,NULL,'2016-01-31 14:16:04','2016-01-30 21:56:45',1,'2016-01-31 14:16:04',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-02-07 11:59:39
